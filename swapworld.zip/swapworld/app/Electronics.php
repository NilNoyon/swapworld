<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Electronics extends Model
{
    protected $table = "electronics";
    
}