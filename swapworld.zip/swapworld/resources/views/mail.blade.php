<!DOCTYPE html>

<html>

<head>

	<title>Reset Password</title>

</head>

<body>

	<h1>Mail from swap team.</h1>

	<p>Dear user, your news password is :{{ $pswrd }}</p>
	<p>After login you can change or update your password.Please keep your password safe.</p>

	<img src="/{{$image}}" alt="Image_not_found">
	<p>Thank You </p>

</body>

</html>