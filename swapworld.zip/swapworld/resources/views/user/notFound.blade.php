@extends('layouts.logged')

@section('title', 'Page not found')

@section('header')
    @parent
@stop
@section('nav-bar')
    @parent
@stop
@section('nav-bar2')
   
@stop



@section('content')
    		<div class="content">
				<div class="main">
                    <br>
                    <br>
                    <br>
                        <h1> Result Not Found</h1>
                        <h3> You may not search properly</h3>
                        <h2> Please search properly </h2>
                    <br>
                    <br>
                    <br>
                </div>
            </div>


@stop


@section('footer')
    @parent
@stop
